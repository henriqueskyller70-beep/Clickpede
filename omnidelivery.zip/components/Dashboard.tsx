import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, Package, ShoppingBag, Settings, Plus, 
  Trash2, Edit, Sparkles, LogOut, Store, Users, FileText, ChevronDown
} from 'lucide-react';
import { Product, Category, StoreProfile, Order } from '../types';
import { storageService } from '../services/storageService';
import { generateProductDescription } from '../services/geminiService';

interface DashboardProps {
    onLogout: () => void;
}

export const Dashboard: React.FC<DashboardProps> = ({ onLogout }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'products' | 'orders' | 'settings'>('overview');
  const [products, setProducts] = useState<Product[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [storeProfile, setStoreProfile] = useState<StoreProfile>(storageService.getStoreProfile());
  const [isStoreOpen, setIsStoreOpen] = useState(true);
  
  // Product Form State
  const [isEditing, setIsEditing] = useState(false);
  const [currentProduct, setCurrentProduct] = useState<Partial<Product>>({});
  const [isGeneratingAi, setIsGeneratingAi] = useState(false);

  useEffect(() => {
    setProducts(storageService.getProducts());
    setOrders(storageService.getOrders());
  }, []);

  const handleSaveProduct = () => {
    if (!currentProduct.name || !currentProduct.price) return;

    let updatedProducts: Product[];
    if (currentProduct.id) {
      // Edit
      updatedProducts = products.map(p => p.id === currentProduct.id ? { ...p, ...currentProduct } as Product : p);
    } else {
      // Create
      const newProduct: Product = {
        ...currentProduct,
        id: Date.now().toString(),
        stock: currentProduct.stock || 0,
        imageUrl: currentProduct.imageUrl || `https://picsum.photos/seed/${Date.now()}/400/300`
      } as Product;
      updatedProducts = [...products, newProduct];
    }
    
    setProducts(updatedProducts);
    storageService.saveProducts(updatedProducts);
    setIsEditing(false);
    setCurrentProduct({});
  };

  const handleDeleteProduct = (id: string) => {
    const updated = products.filter(p => p.id !== id);
    setProducts(updated);
    storageService.saveProducts(updated);
  };

  const handleAiDescription = async () => {
    if (!currentProduct.name || !currentProduct.category) {
      alert("Preencha o nome e a categoria para usar a IA.");
      return;
    }
    setIsGeneratingAi(true);
    const desc = await generateProductDescription(currentProduct.name, currentProduct.category);
    if (desc) {
        setCurrentProduct(prev => ({ ...prev, description: desc }));
    }
    setIsGeneratingAi(false);
  };

  const menuItems = [
      { id: 'overview', label: 'Início', icon: LayoutDashboard },
      { id: 'products', label: 'Produtos / Cardápios', icon: Package },
      { id: 'store', label: 'Loja', icon: Store, hasSubmenu: true },
      { id: 'orders', label: 'Pedidos', icon: ShoppingBag },
      { id: 'clients', label: 'Clientes', icon: Users },
      { id: 'staff', label: 'Funcionários', icon: Users },
      { id: 'reports', label: 'Relatórios', icon: FileText, hasSubmenu: true },
  ];

  return (
    <div className="flex h-screen bg-[#f3f4f6]">
      {/* Sidebar - Dark Theme */}
      <aside className="w-64 bg-[#1f2937] text-gray-300 flex flex-col shadow-2xl z-20">
        <div className="p-5 border-b border-gray-700 flex items-center gap-2">
           <div className="bg-yellow-500 w-1 h-6 rounded-full"></div>
           <h1 className="text-xl font-bold text-white tracking-wide">
             Click <span className="text-yellow-400">PEDE</span>
           </h1>
        </div>

        <nav className="flex-1 py-6 space-y-1">
            {menuItems.map(item => (
                <button
                    key={item.id}
                    onClick={() => {
                        if(item.id === 'overview' || item.id === 'products' || item.id === 'orders') {
                            setActiveTab(item.id as any);
                        } else if (item.id === 'store') {
                            setActiveTab('settings');
                        }
                    }}
                    className={`w-full flex items-center justify-between px-6 py-3.5 transition-all border-l-4 ${
                        activeTab === item.id || (item.id === 'store' && activeTab === 'settings')
                        ? 'bg-[#374151] text-white border-yellow-500' 
                        : 'border-transparent hover:bg-[#374151] hover:text-white'
                    }`}
                >
                    <div className="flex items-center gap-3">
                        <item.icon className={`w-5 h-5 ${activeTab === item.id ? 'text-yellow-400' : ''}`} />
                        <span className="text-sm font-medium">{item.label}</span>
                    </div>
                    {item.hasSubmenu && <ChevronDown className="w-3 h-3 text-gray-500" />}
                </button>
            ))}
        </nav>

        <div className="p-4 border-t border-gray-700 bg-[#111827]">
            <button onClick={onLogout} className="flex items-center gap-2 text-sm text-gray-400 hover:text-white transition-colors w-full px-2 py-2 rounded hover:bg-gray-800">
                <LogOut className="w-4 h-4"/> Sair do Painel
            </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col overflow-hidden">
        
        {/* Top Header */}
        <header className="h-16 bg-white shadow-sm flex items-center justify-between px-8 z-10">
            <div className="flex items-center gap-2">
                <div className="h-8 w-1 bg-black rounded-full"></div>
                <h2 className="text-xl font-bold text-gray-800">{storeProfile.name}</h2>
            </div>

            <div className="flex items-center gap-6">
                <div className="flex items-center gap-3 bg-gray-100 px-4 py-1.5 rounded-full">
                    <span className="text-xs font-semibold text-gray-600">Fechar Loja Temporariamente</span>
                    <button 
                        onClick={() => setIsStoreOpen(!isStoreOpen)}
                        className={`w-10 h-5 rounded-full flex items-center transition-colors p-1 ${isStoreOpen ? 'bg-gray-300 justify-start' : 'bg-green-500 justify-end'}`}
                    >
                         <div className="w-3 h-3 bg-white rounded-full shadow-sm"></div>
                    </button>
                </div>

                <a 
                    href="#/store" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="bg-yellow-400 hover:bg-yellow-500 text-gray-900 px-5 py-2 rounded-lg text-sm font-bold shadow-sm transition-colors flex items-center gap-2"
                >
                    Acesse seu Cardápio
                    <Store className="w-4 h-4" />
                </a>

                <div className="flex items-center gap-3 pl-4 border-l border-gray-200">
                    <div className="text-right">
                         <p className="text-xs text-gray-500">Olá, Administrador</p>
                         <p className="text-sm font-bold text-gray-800">Boa noite</p>
                    </div>
                    <div className="w-10 h-10 bg-gray-200 rounded-full overflow-hidden border-2 border-white shadow-sm">
                        <img src={`https://ui-avatars.com/api/?name=${storeProfile.name}&background=random`} alt="Avatar" />
                    </div>
                </div>
            </div>
        </header>

        {/* Content Scrollable */}
        <main className="flex-1 overflow-y-auto p-8 bg-gray-50">
            
            {/* OVERVIEW TAB */}
            {activeTab === 'overview' && (
                <div className="space-y-8 animate-in fade-in duration-500">
                    <div className="relative w-full rounded-2xl overflow-hidden shadow-xl min-h-[300px] flex">
                        <div className="absolute inset-0 bg-[linear-gradient(115deg,#fbbf24_55%,#2d1a1a_55%)]"></div>
                        <div className="relative z-10 w-full flex items-center">
                            <div className="w-[55%] p-12 pr-20 flex flex-col justify-center h-full">
                                <h1 className="text-4xl font-extrabold text-white drop-shadow-sm mb-4">
                                    Bem-vindo ao Painel!
                                </h1>
                                <h2 className="text-2xl font-bold text-white mb-4">
                                    Gerencie seu delivery com facilidade
                                </h2>
                                <p className="text-white/90 font-medium mb-8 leading-relaxed max-w-lg">
                                    Aqui você controla pedidos, cardápio, clientes e muito mais, tudo de forma rápida e moderna.
                                </p>
                                <div className="flex gap-4">
                                    <button onClick={() => setActiveTab('orders')} className="bg-[#dc2626] text-white px-8 py-3 rounded-full font-bold hover:bg-red-700 transition-colors shadow-lg">
                                        Peça Agora
                                    </button>
                                    <button className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-full font-bold hover:bg-white/10 transition-colors">
                                        Saiba Mais
                                    </button>
                                </div>
                            </div>
                            <div className="w-[45%] h-full relative">
                                <div className="absolute top-10 right-10 w-32 h-32 bg-white/5 rounded-full blur-2xl"></div>
                                <div className="absolute bottom-10 left-10 w-48 h-48 bg-yellow-500/10 rounded-full blur-3xl"></div>
                            </div>
                        </div>
                    </div>
                    {/* ... Stats grid ... */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-6">
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                            <div className="flex items-center justify-between mb-4">
                                <h4 className="text-gray-500 font-medium text-sm">Vendas Totais</h4>
                                <span className="bg-green-100 text-green-600 p-2 rounded-lg"><ShoppingBag size={20} /></span>
                            </div>
                            <p className="text-3xl font-bold text-gray-800">R$ {orders.reduce((acc, curr) => acc + curr.total, 0).toFixed(2)}</p>
                        </div>
                        <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                            <div className="flex items-center justify-between mb-4">
                                <h4 className="text-gray-500 font-medium text-sm">Pedidos Pendentes</h4>
                                <span className="bg-yellow-100 text-yellow-600 p-2 rounded-lg"><Package size={20} /></span>
                            </div>
                            <p className="text-3xl font-bold text-gray-800">{orders.filter(o => o.status === 'pending').length}</p>
                        </div>
                         <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
                            <div className="flex items-center justify-between mb-4">
                                <h4 className="text-gray-500 font-medium text-sm">Produtos Ativos</h4>
                                <span className="bg-blue-100 text-blue-600 p-2 rounded-lg"><Store size={20} /></span>
                            </div>
                            <p className="text-3xl font-bold text-gray-800">{products.length}</p>
                        </div>
                    </div>
                </div>
            )}

            {/* PRODUCTS TAB */}
            {activeTab === 'products' && (
                <div className="space-y-6">
                    <div className="flex justify-between items-center mb-6">
                        <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
                             <Package className="text-yellow-500" />
                             Gerenciar Cardápio
                        </h2>
                        <button 
                            onClick={() => { setIsEditing(true); setCurrentProduct({}); }}
                            className="bg-[#1f2937] text-white px-5 py-2.5 rounded-lg hover:bg-black flex items-center gap-2 shadow-lg transition-colors font-medium"
                        >
                            <Plus className="w-4 h-4" /> Novo Produto
                        </button>
                    </div>

                    {isEditing && (
                        <div className="bg-white p-8 rounded-2xl shadow-xl border border-gray-100 mb-8 animate-in slide-in-from-top-4">
                             <div className="flex justify-between items-center mb-6 border-b border-gray-100 pb-4">
                                <h3 className="text-lg font-bold text-gray-800">
                                    {currentProduct.id ? 'Editar Produto' : 'Cadastrar Novo Item'}
                                </h3>
                                <button onClick={() => setIsEditing(false)} className="text-gray-400 hover:text-red-500 transition-colors">
                                    <Trash2 className="w-5 h-5" />
                                </button>
                            </div>
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div className="space-y-4">
                                    <div>
                                        <label className="text-sm font-semibold text-gray-700">Nome do Item</label>
                                        <input 
                                            type="text" 
                                            className="w-full mt-1 border-gray-300 rounded-lg shadow-sm focus:border-yellow-500 focus:ring-yellow-500 p-3 bg-gray-50"
                                            value={currentProduct.name || ''}
                                            onChange={e => setCurrentProduct({...currentProduct, name: e.target.value})}
                                        />
                                    </div>
                                    <div className="grid grid-cols-2 gap-4">
                                        <div>
                                            <label className="text-sm font-semibold text-gray-700">Preço (R$)</label>
                                            <input 
                                                type="number" step="0.01"
                                                className="w-full mt-1 border-gray-300 rounded-lg shadow-sm focus:border-yellow-500 focus:ring-yellow-500 p-3 bg-gray-50"
                                                value={currentProduct.price || ''}
                                                onChange={e => setCurrentProduct({...currentProduct, price: parseFloat(e.target.value)})}
                                            />
                                        </div>
                                        <div>
                                            <label className="text-sm font-semibold text-gray-700">Estoque</label>
                                            <input 
                                                type="number"
                                                className="w-full mt-1 border-gray-300 rounded-lg shadow-sm focus:border-yellow-500 focus:ring-yellow-500 p-3 bg-gray-50"
                                                value={currentProduct.stock || ''}
                                                onChange={e => setCurrentProduct({...currentProduct, stock: parseInt(e.target.value)})}
                                            />
                                        </div>
                                    </div>
                                    <div>
                                        <label className="text-sm font-semibold text-gray-700">Categoria</label>
                                        <select 
                                            className="w-full mt-1 border-gray-300 rounded-lg shadow-sm focus:border-yellow-500 focus:ring-yellow-500 p-3 bg-gray-50"
                                            value={currentProduct.category || ''}
                                            onChange={e => setCurrentProduct({...currentProduct, category: e.target.value as Category})}
                                        >
                                            <option value="">Selecione...</option>
                                            {Object.values(Category).map(cat => (
                                                <option key={cat} value={cat}>{cat}</option>
                                            ))}
                                        </select>
                                    </div>
                                </div>
                                <div className="space-y-4">
                                    <div>
                                        <label className="text-sm font-semibold text-gray-700">URL da Imagem</label>
                                        <input 
                                            type="text" 
                                            className="w-full mt-1 border-gray-300 rounded-lg shadow-sm focus:border-yellow-500 focus:ring-yellow-500 p-3 bg-gray-50"
                                            value={currentProduct.imageUrl || ''}
                                            onChange={e => setCurrentProduct({...currentProduct, imageUrl: e.target.value})}
                                        />
                                    </div>
                                    <div className="relative">
                                        <label className="text-sm font-semibold text-gray-700">Descrição</label>
                                        <textarea 
                                            className="w-full mt-1 border-gray-300 rounded-lg shadow-sm focus:border-yellow-500 focus:ring-yellow-500 p-3 bg-gray-50 h-32 resize-none"
                                            value={currentProduct.description || ''}
                                            onChange={e => setCurrentProduct({...currentProduct, description: e.target.value})}
                                        />
                                        <button 
                                            onClick={handleAiDescription}
                                            disabled={isGeneratingAi}
                                            className="absolute bottom-3 right-3 bg-gradient-to-r from-purple-500 to-indigo-600 text-white px-3 py-1.5 rounded-full text-xs font-bold flex items-center gap-1 hover:shadow-lg transition-all"
                                        >
                                            <Sparkles className="w-3 h-3" />
                                            {isGeneratingAi ? 'Criando...' : 'IA Mágica'}
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <div className="mt-8 flex justify-end gap-3">
                                <button onClick={() => setIsEditing(false)} className="px-6 py-2.5 rounded-lg text-gray-600 hover:bg-gray-100 font-medium">Cancelar</button>
                                <button onClick={handleSaveProduct} className="bg-yellow-400 text-gray-900 px-8 py-2.5 rounded-lg font-bold hover:bg-yellow-500 shadow-lg transition-colors">
                                    Salvar Alterações
                                </button>
                            </div>
                        </div>
                    )}
                    <div className="bg-white rounded-2xl shadow-sm border border-gray-100 overflow-hidden">
                        <table className="w-full">
                            <thead className="bg-gray-50 border-b border-gray-200">
                                <tr>
                                    <th className="text-left py-4 px-6 text-xs font-bold text-gray-500 uppercase tracking-wider">Item</th>
                                    <th className="text-left py-4 px-6 text-xs font-bold text-gray-500 uppercase tracking-wider">Categoria</th>
                                    <th className="text-left py-4 px-6 text-xs font-bold text-gray-500 uppercase tracking-wider">Valor</th>
                                    <th className="text-right py-4 px-6 text-xs font-bold text-gray-500 uppercase tracking-wider">Gerenciar</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-gray-100">
                                {products.map(product => (
                                    <tr key={product.id} className="hover:bg-gray-50 transition-colors group">
                                        <td className="py-4 px-6 flex items-center gap-4">
                                            <div className="w-12 h-12 rounded-lg bg-gray-100 overflow-hidden">
                                                <img src={product.imageUrl} alt="" className="w-full h-full object-cover" />
                                            </div>
                                            <div>
                                                <p className="font-bold text-gray-800">{product.name}</p>
                                                <p className="text-xs text-gray-400">{product.stock} un. em estoque</p>
                                            </div>
                                        </td>
                                        <td className="py-4 px-6">
                                            <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
                                                {product.category}
                                            </span>
                                        </td>
                                        <td className="py-4 px-6 font-medium text-gray-700">R$ {product.price.toFixed(2)}</td>
                                        <td className="py-4 px-6 text-right">
                                            <div className="flex items-center justify-end gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                                                <button onClick={() => { setCurrentProduct(product); setIsEditing(true); }} className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg"><Edit className="w-4 h-4" /></button>
                                                <button onClick={() => handleDeleteProduct(product.id)} className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg"><Trash2 className="w-4 h-4" /></button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                </div>
            )}

            {/* ORDERS TAB */}
            {activeTab === 'orders' && (
                <div className="space-y-6">
                    <h2 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
                         <ShoppingBag className="text-yellow-500" />
                         Pedidos Recentes
                    </h2>
                    <div className="grid grid-cols-1 gap-4">
                        {orders.map(order => (
                            <div key={order.id} className="bg-white p-6 rounded-xl border border-gray-100 shadow-sm flex flex-col md:flex-row justify-between items-center gap-4">
                                <div className="flex items-center gap-4">
                                    <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-xl ${order.status === 'pending' ? 'bg-yellow-100 text-yellow-600' : 'bg-green-100 text-green-600'}`}>
                                        {order.customerName[0]}
                                    </div>
                                    <div>
                                        <h4 className="font-bold text-gray-900">{order.customerName}</h4>
                                        <p className="text-sm text-gray-500">#{order.id} • {new Date(order.date).toLocaleTimeString()}</p>
                                    </div>
                                </div>
                                <div className="text-right flex items-center gap-6">
                                    <span className="font-bold text-lg text-gray-800">R$ {order.total.toFixed(2)}</span>
                                    <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase ${order.status === 'delivered' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                                        {order.status === 'delivered' ? 'Entregue' : 'Pendente'}
                                    </span>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}
            
            {/* SETTINGS TAB */}
            {activeTab === 'settings' && (
                <div className="max-w-2xl mx-auto bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
                    <h2 className="text-2xl font-bold text-gray-800 mb-6 pb-4 border-b border-gray-100">Configurações da Loja</h2>
                     <div className="space-y-6">
                      <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">Nome da Loja</label>
                          <input 
                            type="text" 
                            className="w-full border border-gray-300 rounded-lg p-3 bg-gray-50"
                            value={storeProfile.name}
                            onChange={(e) => setStoreProfile({...storeProfile, name: e.target.value})}
                          />
                      </div>
                      <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">Descrição</label>
                          <textarea 
                            className="w-full border border-gray-300 rounded-lg p-3 bg-gray-50 h-20 resize-none"
                            value={storeProfile.description}
                            onChange={(e) => setStoreProfile({...storeProfile, description: e.target.value})}
                          />
                      </div>
                      <div className="grid grid-cols-2 gap-4">
                          <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-2">Endereço (Vitrine)</label>
                            <input 
                                type="text" 
                                className="w-full border border-gray-300 rounded-lg p-3 bg-gray-50"
                                value={storeProfile.address || ''}
                                onChange={(e) => setStoreProfile({...storeProfile, address: e.target.value})}
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-semibold text-gray-700 mb-2">Telefone</label>
                            <input 
                                type="text" 
                                className="w-full border border-gray-300 rounded-lg p-3 bg-gray-50"
                                value={storeProfile.phone || ''}
                                onChange={(e) => setStoreProfile({...storeProfile, phone: e.target.value})}
                            />
                          </div>
                      </div>
                      <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">URL da Capa (Banner)</label>
                          <input 
                            type="text" 
                            className="w-full border border-gray-300 rounded-lg p-3 bg-gray-50"
                            value={storeProfile.coverUrl || ''}
                            onChange={(e) => setStoreProfile({...storeProfile, coverUrl: e.target.value})}
                            placeholder="https://..."
                          />
                          {storeProfile.coverUrl && (
                              <div className="mt-2 h-32 w-full rounded-lg overflow-hidden border border-gray-200">
                                  <img src={storeProfile.coverUrl} className="w-full h-full object-cover" />
                              </div>
                          )}
                      </div>
                      <div>
                          <label className="block text-sm font-semibold text-gray-700 mb-2">Cor da Marca</label>
                          <div className="flex items-center gap-4">
                            <input 
                                type="color" 
                                className="h-10 w-20 rounded cursor-pointer border-0 p-0"
                                value={storeProfile.primaryColor}
                                onChange={(e) => setStoreProfile({...storeProfile, primaryColor: e.target.value})}
                            />
                          </div>
                      </div>
                      <div className="pt-6 flex justify-end">
                        <button 
                            onClick={() => {
                                storageService.saveStoreProfile(storeProfile);
                                alert("Salvo com sucesso!");
                            }}
                            className="bg-gray-900 text-white px-8 py-3 rounded-lg hover:bg-black font-bold shadow-lg"
                        >
                            Salvar Configurações
                        </button>
                      </div>
                  </div>
                </div>
            )}
        </main>
      </div>
    </div>
  );
};