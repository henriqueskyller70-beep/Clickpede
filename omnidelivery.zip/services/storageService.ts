import { Product, Category, StoreProfile, Order, Address } from '../types';

const PRODUCTS_KEY = 'omnidelivery_products';
const STORE_KEY = 'omnidelivery_store';
const ORDERS_KEY = 'omnidelivery_orders';
const USER_ADDRESS_KEY = 'omnidelivery_user_address';

// Initial Mock Data
const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Combo Whopper Supremo',
    description: 'Hambúrguer grelhado no fogo, queijo derretido, bacon, salada fresca e maionese especial + Batata Frita G.',
    price: 42.90,
    category: Category.FOOD,
    imageUrl: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?auto=format&fit=crop&w=500&q=80',
    stock: 50
  },
  {
    id: '2',
    name: 'Pizza Calabresa Acebolada',
    description: 'Molho de tomate artesanal, mussarela, calabresa fatiada e cebola roxa. Borda recheada opcional.',
    price: 59.90,
    category: Category.FOOD,
    imageUrl: 'https://images.unsplash.com/photo-1628840042765-356cda07504e?auto=format&fit=crop&w=500&q=80',
    stock: 20
  },
  {
    id: '3',
    name: 'Coca-Cola 2L',
    description: 'Refrigerante Coca-Cola Garrafa 2 Litros, ideal para compartilhar.',
    price: 14.00,
    category: Category.FOOD,
    imageUrl: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?auto=format&fit=crop&w=500&q=80',
    stock: 100
  },
  {
    id: '4',
    name: 'Camisa Polo Clássica',
    description: '100% Algodão, piquet duplo. Várias cores disponíveis.',
    price: 89.90,
    category: Category.CLOTHING,
    imageUrl: 'https://images.unsplash.com/photo-1581655353564-df123a1eb820?auto=format&fit=crop&w=500&q=80',
    stock: 15
  }
];

const INITIAL_STORE: StoreProfile = {
  name: 'Click PEDE',
  description: 'Sua comida favorita na sua porta em minutos.',
  primaryColor: '#9f1239', 
  logoUrl: 'https://cdn-icons-png.flaticon.com/512/3075/3075977.png',
  coverUrl: 'https://images.unsplash.com/photo-1504674900247-0877df9cc836?auto=format&fit=crop&w=1200&q=80',
  address: 'Av. Principal, 1000 - Centro, São Paulo - SP',
  phone: '(11) 99999-9999'
};

const INITIAL_ORDERS: Order[] = [
  {
    id: 'ORD-001',
    customerName: 'João Silva',
    items: [
        { ...INITIAL_PRODUCTS[0], quantity: 2 }
    ],
    total: 85.80,
    status: 'delivered',
    date: new Date(Date.now() - 86400000).toISOString()
  },
  {
    id: 'ORD-002',
    customerName: 'Maria Santos',
    items: [
        { ...INITIAL_PRODUCTS[2], quantity: 1 }
    ],
    total: 14.00,
    status: 'pending',
    date: new Date().toISOString()
  }
];

export const storageService = {
  getProducts: (): Product[] => {
    const data = localStorage.getItem(PRODUCTS_KEY);
    return data ? JSON.parse(data) : INITIAL_PRODUCTS;
  },

  saveProducts: (products: Product[]) => {
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
  },

  getStoreProfile: (): StoreProfile => {
    const data = localStorage.getItem(STORE_KEY);
    return data ? JSON.parse(data) : INITIAL_STORE;
  },

  saveStoreProfile: (profile: StoreProfile) => {
    localStorage.setItem(STORE_KEY, JSON.stringify(profile));
  },
  
  getOrders: (): Order[] => {
      const data = localStorage.getItem(ORDERS_KEY);
      return data ? JSON.parse(data) : INITIAL_ORDERS;
  },

  getUserAddress: (): Address | null => {
    const data = localStorage.getItem(USER_ADDRESS_KEY);
    return data ? JSON.parse(data) : null;
  },

  saveUserAddress: (address: Address) => {
    localStorage.setItem(USER_ADDRESS_KEY, JSON.stringify(address));
  }
};