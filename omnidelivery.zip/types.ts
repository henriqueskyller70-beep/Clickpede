export enum Category {
  FOOD = 'Alimentos',
  CLOTHING = 'Roupas',
  PHARMACY = 'Farmácia',
  ELECTRONICS = 'Eletrônicos',
  OTHER = 'Outros'
}

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: Category;
  imageUrl: string;
  stock: number;
}

export interface StoreProfile {
  name: string;
  description: string;
  primaryColor: string;
  logoUrl: string;
  coverUrl?: string; // Nova capa
  address?: string; // Endereço da loja
  phone?: string;   // Contato
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Address {
  street: string;
  number: string;
  neighborhood: string;
  city: string;
  complement?: string;
  reference?: string;
}

export interface Order {
  id: string;
  customerName: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'preparing' | 'delivered';
  date: string;
}